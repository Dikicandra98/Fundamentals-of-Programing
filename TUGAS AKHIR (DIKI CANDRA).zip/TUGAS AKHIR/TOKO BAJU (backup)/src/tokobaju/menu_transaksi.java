/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package tokobaju;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;


public class menu_transaksi extends javax.swing.JFrame {
    private DefaultTableModel model = null;
    private PreparedStatement stat;
    private ResultSet rs;
    koneksi k = new koneksi();
    
    public menu_transaksi() {
        initComponents();
        k.connect();
        refreshTable();
        refreshCombo();
    }
    
    class  transaksi extends menu_transaksi{
        int id_transaksi, id_barang, harga, jumlah_beli, total_bayar;
        String nama_pelanggan, tanggal, nama_barang;

        public transaksi() {
            this.nama_pelanggan = text_nama_pelanggan.getText();
            String combo = combo_id_masakan.getSelectedItem().toString();
            String[] arr = combo.split(":");
            this.id_barang = Integer.parseInt(arr[0]);
            try {
                Date date = text_tanggal.getDate();
                DateFormat dateformat = new SimpleDateFormat("YYYY-MM-dd");
                this.tanggal = dateformat.format(date);
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, e.getMessage());
            }
            this.nama_barang = arr[1];
            this.harga = Integer.parseInt(arr[2]);
            this.jumlah_beli = Integer.parseUnsignedInt(text_jumlah_beli.getText());
            this.total_bayar = this.harga * this.jumlah_beli;
        }
    }

    public void refreshTable(){
        model = new DefaultTableModel();
        model.addColumn("ID Transaksi");
        model.addColumn("Nama Pelanggan");
        model.addColumn("ID Barang");
        model.addColumn("Tanggal");
        model.addColumn("Nama Barang");
        model.addColumn("Harga");
        model.addColumn("Jumlah Beli");
        model.addColumn("Total Bayar");
        table_transaksi.setModel(model);
        try {
            this.stat = k.getCon().prepareStatement("select * from transaksi");
            this.rs = this.stat.executeQuery();
            while (rs.next()){
                Object[] data={
                    rs.getString(1),
                    rs.getString(2),
                    rs.getString(3),
                    rs.getString(4),
                    rs.getString(5),
                    rs.getString(6),
                    rs.getString(7),
                    rs.getString(8),
                    
                };
                model.addRow(data);
        }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
        text_id_transaksi.setText("");
        text_nama_pelanggan.setText("");
        text_jumlah_beli.setText("");
        text_total_bayar.setText("");
    }
    
    public void refreshCombo(){
        try {
           this.stat = k.getCon().prepareStatement("select * from barang "
           + "where status='Tersedia'");
           this.rs = this.stat.executeQuery();
           while (rs.next()){
               combo_id_masakan.addItem(rs.getString("id_barang")+":"+
               rs.getString("nama_barang")+":"+rs.getString("harga"));
           }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        text_id_transaksi = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        text_nama_pelanggan = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        combo_id_masakan = new javax.swing.JComboBox<>();
        jScrollPane1 = new javax.swing.JScrollPane();
        table_transaksi = new javax.swing.JTable();
        jButton1 = new javax.swing.JButton();
        btn_logout = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        text_jumlah_beli = new javax.swing.JTextField();
        btn_menu_masakan = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        text_total_bayar = new javax.swing.JTextField();
        text_tanggal = new com.toedter.calendar.JDateChooser();
        btn_input = new javax.swing.JButton();
        btn_update = new javax.swing.JButton();
        btn_delete = new javax.swing.JButton();
        jLabel9 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        jLabel1.setFont(new java.awt.Font("Corbel", 1, 24)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("MENU TRANSAKSI");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(40, 40, 575, 52);

        jLabel2.setFont(new java.awt.Font("Arial Narrow", 1, 18)); // NOI18N
        jLabel2.setText("Nama Pelanggaan");
        getContentPane().add(jLabel2);
        jLabel2.setBounds(31, 160, 160, 21);

        text_id_transaksi.setFont(new java.awt.Font("Consolas", 1, 18)); // NOI18N
        text_id_transaksi.setEnabled(false);
        getContentPane().add(text_id_transaksi);
        text_id_transaksi.setBounds(205, 111, 387, 28);

        jLabel3.setFont(new java.awt.Font("Arial Narrow", 1, 18)); // NOI18N
        jLabel3.setText("ID Transaksi");
        getContentPane().add(jLabel3);
        jLabel3.setBounds(31, 114, 129, 21);

        text_nama_pelanggan.setFont(new java.awt.Font("Consolas", 1, 18)); // NOI18N
        getContentPane().add(text_nama_pelanggan);
        text_nama_pelanggan.setBounds(205, 157, 387, 28);

        jLabel4.setFont(new java.awt.Font("Arial Narrow", 1, 18)); // NOI18N
        jLabel4.setText("ID Barang");
        getContentPane().add(jLabel4);
        jLabel4.setBounds(31, 213, 108, 21);

        jLabel5.setFont(new java.awt.Font("Arial Narrow", 1, 18)); // NOI18N
        jLabel5.setText("Total Bayar");
        getContentPane().add(jLabel5);
        jLabel5.setBounds(31, 371, 120, 36);

        combo_id_masakan.setFont(new java.awt.Font("Bahnschrift", 1, 14)); // NOI18N
        getContentPane().add(combo_id_masakan);
        combo_id_masakan.setBounds(205, 203, 235, 32);

        table_transaksi.setBackground(new java.awt.Color(238, 192, 209));
        table_transaksi.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        table_transaksi.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                table_transaksiMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(table_transaksi);

        getContentPane().add(jScrollPane1);
        jScrollPane1.setBounds(0, 490, 670, 180);

        jButton1.setBackground(new java.awt.Color(232, 176, 176));
        jButton1.setFont(new java.awt.Font("Arial Narrow", 1, 14)); // NOI18N
        jButton1.setText("MENU");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1);
        jButton1.setBounds(555, 20, 90, 30);

        btn_logout.setBackground(new java.awt.Color(255, 204, 204));
        btn_logout.setFont(new java.awt.Font("Consolas", 1, 14)); // NOI18N
        btn_logout.setText("LOGOUT");
        btn_logout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_logoutActionPerformed(evt);
            }
        });
        getContentPane().add(btn_logout);
        btn_logout.setBounds(30, 20, 94, 41);

        jLabel6.setFont(new java.awt.Font("Arial Narrow", 1, 18)); // NOI18N
        jLabel6.setText("Tanggal");
        getContentPane().add(jLabel6);
        jLabel6.setBounds(31, 269, 93, 21);

        text_jumlah_beli.setFont(new java.awt.Font("Consolas", 1, 18)); // NOI18N
        text_jumlah_beli.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                text_jumlah_beliActionPerformed(evt);
            }
        });
        getContentPane().add(text_jumlah_beli);
        text_jumlah_beli.setBounds(205, 321, 387, 28);

        btn_menu_masakan.setBackground(new java.awt.Color(255, 204, 204));
        btn_menu_masakan.setFont(new java.awt.Font("Arial Narrow", 0, 14)); // NOI18N
        btn_menu_masakan.setText("MODEL BARANG");
        btn_menu_masakan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_menu_masakanActionPerformed(evt);
            }
        });
        getContentPane().add(btn_menu_masakan);
        btn_menu_masakan.setBounds(458, 204, 130, 30);

        jLabel7.setFont(new java.awt.Font("Arial Narrow", 1, 18)); // NOI18N
        jLabel7.setText("Jumlah beli");
        getContentPane().add(jLabel7);
        jLabel7.setBounds(31, 324, 120, 21);

        text_total_bayar.setFont(new java.awt.Font("Consolas", 1, 18)); // NOI18N
        text_total_bayar.setEnabled(false);
        text_total_bayar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                text_total_bayarActionPerformed(evt);
            }
        });
        getContentPane().add(text_total_bayar);
        text_total_bayar.setBounds(205, 375, 387, 28);

        text_tanggal.setBackground(new java.awt.Color(255, 204, 204));
        text_tanggal.setFont(new java.awt.Font("Consolas", 1, 18)); // NOI18N
        getContentPane().add(text_tanggal);
        text_tanggal.setBounds(205, 269, 387, 22);

        btn_input.setBackground(new java.awt.Color(255, 204, 204));
        btn_input.setFont(new java.awt.Font("Consolas", 1, 14)); // NOI18N
        btn_input.setText("TAMBAH");
        btn_input.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_inputActionPerformed(evt);
            }
        });
        getContentPane().add(btn_input);
        btn_input.setBounds(200, 420, 115, 50);

        btn_update.setBackground(new java.awt.Color(255, 204, 204));
        btn_update.setFont(new java.awt.Font("Arial Narrow", 1, 14)); // NOI18N
        btn_update.setText("UPDATE");
        btn_update.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_updateActionPerformed(evt);
            }
        });
        getContentPane().add(btn_update);
        btn_update.setBounds(340, 420, 115, 50);

        btn_delete.setBackground(new java.awt.Color(255, 204, 204));
        btn_delete.setFont(new java.awt.Font("Arial Narrow", 1, 14)); // NOI18N
        btn_delete.setText("HAPUS");
        btn_delete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_deleteActionPerformed(evt);
            }
        });
        getContentPane().add(btn_delete);
        btn_delete.setBounds(480, 420, 115, 50);

        jLabel9.setIcon(new javax.swing.ImageIcon("C:\\Users\\dikis\\Downloads\\transaksi.jpeg")); // NOI18N
        getContentPane().add(jLabel9);
        jLabel9.setBounds(-10, -120, 680, 810);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void text_jumlah_beliActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_text_jumlah_beliActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_text_jumlah_beliActionPerformed

    private void text_total_bayarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_text_total_bayarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_text_total_bayarActionPerformed

    private void btn_logoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_logoutActionPerformed

        login l = new login();
        l.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_btn_logoutActionPerformed

    private void btn_inputActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_inputActionPerformed
        try {
            transaksi tran = new transaksi();
            text_total_bayar.setText(""+tran.total_bayar);
            this.stat = k.getCon().prepareStatement("insert into transaksi values(?,?,?,?,?,?,?,?)");
            this.stat.setInt(1, 0);
            this.stat.setString(2, tran.nama_pelanggan);
            this.stat.setInt(3, tran.id_barang);
            this.stat.setString(4, tran.tanggal);
            this.stat.setString(5, tran.nama_barang);
            this.stat.setInt(6, tran.harga);
            this.stat.setInt(7, tran.jumlah_beli);
            this.stat.setInt(8, tran.total_bayar);
            int pilihan = JOptionPane.showConfirmDialog(null
                    , "Tanggal: "+tran.tanggal+
                            "\nNama Pelanggan: "+tran.nama_pelanggan+
                            "\nPembelian : "+tran.jumlah_beli+""+tran.nama_barang+
                            "Total Bayar: "+tran.total_bayar+"\n",
                    "Tambahkan Transaksi?",
                    JOptionPane.YES_NO_OPTION);
            if (pilihan == JOptionPane.YES_OPTION) {
                this.stat.executeUpdate();
                refreshTable();
            } else if(pilihan == JOptionPane.NO_OPTION){
                refreshTable();
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }//GEN-LAST:event_btn_inputActionPerformed

    private void btn_updateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_updateActionPerformed

        try {
            transaksi tran = new transaksi();
            tran.id_transaksi = Integer.parseInt(text_id_transaksi.getText());
            this.stat = k.getCon().prepareStatement("update transaksi set nama_pelanggan=?,"
                    + "id_masakan=?,tanggal=?,nama_masakan=?,harga=?,jumlah_beli=?,total_bayar=? "
                    + "where id_transaksi=?");
            this.stat.setString(1, tran.nama_pelanggan);
            this.stat.setInt(2, tran.id_barang);
            this.stat.setString(3, tran.tanggal);
            this.stat.setString(4, tran.nama_barang);
            this.stat.setInt(5, tran.harga);
            this.stat.setInt(6, tran.jumlah_beli);
            this.stat.setInt(7, tran.total_bayar);
            this.stat.setInt(8, tran.id_transaksi);
            this.stat.executeUpdate();
            refreshTable();
             
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }//GEN-LAST:event_btn_updateActionPerformed

    private void table_transaksiMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_table_transaksiMouseClicked

        text_id_transaksi.setText(model.getValueAt(table_transaksi.getSelectedRow(),0).toString());
        text_nama_pelanggan.setText(model.getValueAt(table_transaksi.getSelectedRow(),1).toString());
        text_jumlah_beli.setText(model.getValueAt(table_transaksi.getSelectedRow(),6).toString());
        text_total_bayar.setText(model.getValueAt(table_transaksi.getSelectedRow(),7).toString());
    }//GEN-LAST:event_table_transaksiMouseClicked

    private void btn_deleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_deleteActionPerformed
 
        try {
            transaksi tran = new transaksi();
            tran.id_transaksi = Integer.parseInt(text_id_transaksi.getText());
            this.stat = k.getCon().prepareStatement("delete from transaksi "
            + "where id_transaksi=?");
            this.stat.setInt(1, tran.id_transaksi);
            this.stat.executeUpdate();
            refreshTable();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }//GEN-LAST:event_btn_deleteActionPerformed

    private void btn_menu_masakanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_menu_masakanActionPerformed

        menu_barang masak = new menu_barang();
        masak.setVisible(true);
        this.setVisible(false);
        masak.btn_delete.setEnabled(true);
        masak.btn_input.setEnabled(true);
        masak.btn_update.setEnabled(true);
        masak.btn_transaksi.setEnabled(true);
    }//GEN-LAST:event_btn_menu_masakanActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed

        menu utama = new menu();
                        utama.setVisible(true);
                        this.setVisible(false);
    }//GEN-LAST:event_jButton1ActionPerformed

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new menu_transaksi().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    public javax.swing.JButton btn_delete;
    public javax.swing.JButton btn_input;
    public javax.swing.JButton btn_logout;
    private javax.swing.JButton btn_menu_masakan;
    public javax.swing.JButton btn_update;
    private javax.swing.JComboBox<String> combo_id_masakan;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable table_transaksi;
    private javax.swing.JTextField text_id_transaksi;
    private javax.swing.JTextField text_jumlah_beli;
    private javax.swing.JTextField text_nama_pelanggan;
    private com.toedter.calendar.JDateChooser text_tanggal;
    private javax.swing.JTextField text_total_bayar;
    // End of variables declaration//GEN-END:variables
}
