/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package tokobaju;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;


public class menu_barang extends javax.swing.JFrame {
    private DefaultTableModel model = null;
    private PreparedStatement stat;
    private ResultSet rs;
    koneksi k = new koneksi();

    public menu_barang() {
        initComponents();
        k.connect();
        refreshTable();
    }
    
    class masakan extends menu_barang{
        int id_barang, harga;
        String nama_barang, status;

        public masakan() {
            this.nama_barang = text_nama_masakan.getText();
            this.harga = Integer.parseInt(text_harga_masakan.getText());
            this.status = combo_status_masakan.getSelectedItem().toString();
        }
       
    }
       public void refreshTable(){
           model = new DefaultTableModel();
           model.addColumn("ID Barang");
           model.addColumn("Nama Barang");
           model.addColumn("Harga");
           model.addColumn("Status Barang");
           table_masakan.setModel(model);
           try {
              this.stat = k.getCon().prepareStatement("select * from barang");
              this.rs = this.stat.executeQuery();
               while (rs.next()) {
                   Object[] data={
                       rs.getInt("id_barang"),
                       rs.getString("nama_barang"),
                       rs.getInt("harga"),
                       rs.getString("status"),  
                   };
                   model.addRow(data);
               }
           } catch (Exception e) {
               JOptionPane.showMessageDialog(null, e.getMessage());
           }
           text_id_masakan.setText("");
           text_nama_masakan.setText("");
           text_harga_masakan.setText("");  
       }
       
       
    @SuppressWarnings("unchecked")
    
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        text_harga_masakan = new javax.swing.JTextField();
        text_id_masakan = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        text_nama_masakan = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        combo_status_masakan = new javax.swing.JComboBox<>();
        jScrollPane1 = new javax.swing.JScrollPane();
        table_masakan = new javax.swing.JTable();
        jButton1 = new javax.swing.JButton();
        btn_logout = new javax.swing.JButton();
        btn_update = new javax.swing.JButton();
        btn_input = new javax.swing.JButton();
        btn_transaksi = new javax.swing.JButton();
        btn_delete = new javax.swing.JButton();
        btn_registrasi = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        jLabel1.setFont(new java.awt.Font("Consolas", 1, 28)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("FASHION");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(250, 40, 120, 40);

        jLabel2.setFont(new java.awt.Font("Arial Narrow", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Nama Barang ");
        getContentPane().add(jLabel2);
        jLabel2.setBounds(110, 180, 146, 21);

        text_harga_masakan.setFont(new java.awt.Font("Bahnschrift", 1, 14)); // NOI18N
        getContentPane().add(text_harga_masakan);
        text_harga_masakan.setBounds(220, 220, 380, 24);

        text_id_masakan.setFont(new java.awt.Font("Bahnschrift", 1, 14)); // NOI18N
        text_id_masakan.setEnabled(false);
        getContentPane().add(text_id_masakan);
        text_id_masakan.setBounds(220, 140, 380, 24);

        jLabel3.setFont(new java.awt.Font("Arial Narrow", 1, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(204, 255, 255));
        jLabel3.setText("ID Barang ");
        getContentPane().add(jLabel3);
        jLabel3.setBounds(110, 140, 118, 21);

        text_nama_masakan.setFont(new java.awt.Font("Bahnschrift", 1, 14)); // NOI18N
        getContentPane().add(text_nama_masakan);
        text_nama_masakan.setBounds(220, 180, 380, 24);

        jLabel4.setFont(new java.awt.Font("Arial Narrow", 1, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Harga");
        getContentPane().add(jLabel4);
        jLabel4.setBounds(110, 220, 146, 22);

        jLabel5.setFont(new java.awt.Font("Arial Narrow", 1, 18)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Status Barang");
        getContentPane().add(jLabel5);
        jLabel5.setBounds(110, 270, 165, 21);

        combo_status_masakan.setFont(new java.awt.Font("Bahnschrift", 1, 14)); // NOI18N
        combo_status_masakan.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Tersedia", "Habis" }));
        getContentPane().add(combo_status_masakan);
        combo_status_masakan.setBounds(220, 260, 380, 32);

        table_masakan.setBackground(new java.awt.Color(144, 139, 227));
        table_masakan.setFont(new java.awt.Font("Bahnschrift", 1, 12)); // NOI18N
        table_masakan.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        table_masakan.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                table_masakanMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(table_masakan);

        getContentPane().add(jScrollPane1);
        jScrollPane1.setBounds(30, 420, 580, 160);

        jButton1.setFont(new java.awt.Font("Arial Narrow", 1, 14)); // NOI18N
        jButton1.setText("MENU");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1);
        jButton1.setBounds(270, 590, 72, 24);

        btn_logout.setBackground(new java.awt.Color(144, 139, 227));
        btn_logout.setFont(new java.awt.Font("Arial Narrow", 1, 18)); // NOI18N
        btn_logout.setForeground(new java.awt.Color(255, 255, 255));
        btn_logout.setText("logout");
        btn_logout.setEnabled(false);
        btn_logout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_logoutActionPerformed(evt);
            }
        });
        getContentPane().add(btn_logout);
        btn_logout.setBounds(30, 10, 90, 41);

        btn_update.setBackground(new java.awt.Color(144, 139, 227));
        btn_update.setFont(new java.awt.Font("Arial Narrow", 1, 14)); // NOI18N
        btn_update.setForeground(new java.awt.Color(255, 255, 255));
        btn_update.setText("UPDATE");
        btn_update.setEnabled(false);
        btn_update.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_updateActionPerformed(evt);
            }
        });
        getContentPane().add(btn_update);
        btn_update.setBounds(180, 340, 115, 50);

        btn_input.setBackground(new java.awt.Color(144, 139, 227));
        btn_input.setFont(new java.awt.Font("Arial Narrow", 1, 14)); // NOI18N
        btn_input.setForeground(new java.awt.Color(255, 255, 255));
        btn_input.setText("TAMBAH");
        btn_input.setEnabled(false);
        btn_input.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_inputActionPerformed(evt);
            }
        });
        getContentPane().add(btn_input);
        btn_input.setBounds(40, 340, 115, 50);

        btn_transaksi.setBackground(new java.awt.Color(144, 139, 227));
        btn_transaksi.setFont(new java.awt.Font("Arial Narrow", 1, 14)); // NOI18N
        btn_transaksi.setForeground(new java.awt.Color(255, 255, 255));
        btn_transaksi.setText("PEMBAYARAN");
        btn_transaksi.setEnabled(false);
        btn_transaksi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_transaksiActionPerformed(evt);
            }
        });
        getContentPane().add(btn_transaksi);
        btn_transaksi.setBounds(460, 340, 140, 50);

        btn_delete.setBackground(new java.awt.Color(144, 139, 227));
        btn_delete.setFont(new java.awt.Font("Arial Narrow", 1, 14)); // NOI18N
        btn_delete.setForeground(new java.awt.Color(255, 255, 255));
        btn_delete.setText("HAPUS");
        btn_delete.setEnabled(false);
        btn_delete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_deleteActionPerformed(evt);
            }
        });
        getContentPane().add(btn_delete);
        btn_delete.setBounds(320, 340, 115, 50);

        btn_registrasi.setBackground(new java.awt.Color(144, 139, 227));
        btn_registrasi.setFont(new java.awt.Font("Arial Narrow", 1, 14)); // NOI18N
        btn_registrasi.setForeground(new java.awt.Color(255, 255, 255));
        btn_registrasi.setText("BUAT AKUN");
        btn_registrasi.setEnabled(false);
        btn_registrasi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_registrasiActionPerformed(evt);
            }
        });
        getContentPane().add(btn_registrasi);
        btn_registrasi.setBounds(490, 10, 110, 30);

        jLabel6.setIcon(new javax.swing.ImageIcon("C:\\Users\\dikis\\Downloads\\rakbaju (1).jpeg")); // NOI18N
        getContentPane().add(jLabel6);
        jLabel6.setBounds(0, -10, 650, 640);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btn_inputActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_inputActionPerformed

        try {
            masakan m = new masakan();
           this.stat = k.getCon().prepareStatement("insert into barang values(?,?,?,?)");
           stat.setInt(1, 0);
           stat.setString(2, m.nama_barang);
           stat.setInt(3, m.harga);
           stat.setString(4, m.status);
           stat.executeUpdate();
           refreshTable();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }//GEN-LAST:event_btn_inputActionPerformed

    private void table_masakanMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_table_masakanMouseClicked

        text_id_masakan.setText(model.getValueAt(table_masakan.getSelectedRow(), 0).toString());
        text_nama_masakan.setText(model.getValueAt(table_masakan.getSelectedRow(), 1).toString());
        text_harga_masakan.setText(model.getValueAt(table_masakan.getSelectedRow(), 2).toString());
        
    }//GEN-LAST:event_table_masakanMouseClicked

    private void btn_updateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_updateActionPerformed

        try {
            masakan m = new masakan();
            this.stat = k.getCon().prepareStatement("update barang set nama_barang=?,"
            + "harga=?,status=? where id_barang=?");
            stat.setString(1, m.nama_barang);
            stat.setInt(2, m.harga);
            stat.setString(3, m.status);
            stat.setInt(4, Integer.parseInt(text_id_masakan.getText()));
            stat.executeUpdate();
            refreshTable();
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }//GEN-LAST:event_btn_updateActionPerformed

    private void btn_deleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_deleteActionPerformed

        try {
           this.stat = k.getCon().prepareStatement("delete from barang where id_barang=?");
           stat.setInt(1, Integer.parseInt(text_id_masakan.getText()));
           stat.executeUpdate();
           refreshTable();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }//GEN-LAST:event_btn_deleteActionPerformed

    private void btn_registrasiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_registrasiActionPerformed

        menu_registrasi reg = new menu_registrasi();
        reg.setVisible(true);
        this.setVisible(false);
        
    }//GEN-LAST:event_btn_registrasiActionPerformed

    private void btn_transaksiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_transaksiActionPerformed

        menu_transaksi tran = new menu_transaksi();
        tran.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_btn_transaksiActionPerformed

    private void btn_logoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_logoutActionPerformed

        login l = new login();
        l.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_btn_logoutActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed

        menu utama = new menu();
                        utama.setVisible(true);
                        this.setVisible(false);
    }//GEN-LAST:event_jButton1ActionPerformed

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new menu_barang().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    public javax.swing.JButton btn_delete;
    public javax.swing.JButton btn_input;
    public javax.swing.JButton btn_logout;
    public javax.swing.JButton btn_registrasi;
    public javax.swing.JButton btn_transaksi;
    public javax.swing.JButton btn_update;
    private javax.swing.JComboBox<String> combo_status_masakan;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable table_masakan;
    private javax.swing.JTextField text_harga_masakan;
    private javax.swing.JTextField text_id_masakan;
    private javax.swing.JTextField text_nama_masakan;
    // End of variables declaration//GEN-END:variables
}
